package org.example.spotifysecondfase.view.Exception;

public class InvalidFormat extends Exception
{
    public InvalidFormat(String massage)
    {
        super("Invalid format");
    }
}
