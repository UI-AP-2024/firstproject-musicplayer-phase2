package controller;

import model.Audio.Audio;
import model.Database;
import model.Report;
import model.UserAccount.UserAccount;

import java.util.ArrayList;

public class DatabaseController {
    static Database database;
//    public Database newDatabase(ArrayList<UserAccount> userAccounts, ArrayList<Audio> audio, ArrayList<Report> reports)
//    {
//        database = newDatabase(userAccounts,audio,reports);
//        Database.getDatabase(userAccounts,audio,reports);
//
//    }
}
