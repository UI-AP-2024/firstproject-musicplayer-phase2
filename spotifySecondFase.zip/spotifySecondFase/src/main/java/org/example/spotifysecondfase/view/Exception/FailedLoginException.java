package org.example.spotifysecondfase.view.Exception;

public class FailedLoginException extends Exception
{
    public FailedLoginException(String massage)
    {
        super(massage);
    }
}
