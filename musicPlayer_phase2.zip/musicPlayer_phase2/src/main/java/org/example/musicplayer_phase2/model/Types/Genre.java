package org.example.musicplayer_phase2.model.Types;

public enum Genre
{
    ROCK , POP , JAZZ , HIPHOP , COUNTRY , TRUECRIME , SOCIETY , INTERVIEW , HISTORY
}
